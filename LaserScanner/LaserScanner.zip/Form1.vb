﻿Imports System.ComponentModel
Imports AForge.Imaging
Imports AForge.Video.DirectShow
Imports System.IO
Imports MathNet.Numerics.Interpolation
Public Class Form1

    Dim stage As ZaberNew
    Public Const nSeris As Integer = 100
    Public Const nCol As Integer = 900 '640
    Public nRow As Integer = 100
    Public yCrop As Integer
    Public Const xCrop As Integer = 485
    Public Const binSize As Integer = 10
    Dim laserPosMat(nSeris - 1, nCol - 1) As Double
    Dim sampleZMat(nRow - 1, nCol - 1) As Double
    Dim btnCalibPress As Boolean = False

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        stage = New ZaberNew()
        Dim videoDevices As New FilterInfoCollection(FilterCategory.VideoInputDevice)
        Dim videoSource As New VideoCaptureDevice(videoDevices(0).MonikerString)
        videoSource.VideoResolution = videoSource.VideoCapabilities(10) '1920*1080
        videoSource.SnapshotResolution = videoSource.VideoCapabilities(10)
        VideoSourcePlayer1.VideoSource = videoSource
        'Dim minFocus, maxFocus, stepFocus, defFocus As Integer
        'videoSource.GetCameraPropertyRange(CameraControlProperty.Focus, minFocus, maxFocus, stepFocus, defFocus, CameraControlFlags.Manual)
        'Focus ranges from 0 to 40 in integer steps
        'videoSource.GetCameraPropertyRange(CameraControlProperty.Exposure, minFocus, maxFocus, stepFocus, defFocus, CameraControlFlags.Manual)
        'Zoom ranges from 0 to 317 in integer steps
        'Exposure ranges from -13 to 0 in integer steps
        videoSource.SetCameraProperty(CameraControlProperty.Focus, NumericUpDownFocus.Value, CameraControlFlags.Manual)
        videoSource.SetCameraProperty(CameraControlProperty.Exposure, NumericUpDownExposure.Value, CameraControlFlags.Manual)
        videoSource.Start()
        VideoSourcePlayer1.Start()
    End Sub

    Public Function MaxArray1(ByRef a(,) As Double, nR As Integer) As Double
        Dim max As Double = a(0, 1)
        For iR As Integer = 1 To nR - 1
            If max < a(iR, 1) Then
                max = a(iR, 1)
            End If
        Next
        Return max
    End Function

    Public Sub NumericUpDown_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDownFocus.ValueChanged,
            NumericUpDownExposure.ValueChanged, TrackBarTopCrop.ValueChanged, TrackBarBottomCrop.ValueChanged
        Dim videoDevices As New FilterInfoCollection(FilterCategory.VideoInputDevice)
        Dim videoSource As New VideoCaptureDevice(videoDevices(0).MonikerString)
        Try
            videoSource.SetCameraProperty(CameraControlProperty.Focus, NumericUpDownFocus.Value, CameraControlFlags.Manual)
            videoSource.SetCameraProperty(CameraControlProperty.Exposure, NumericUpDownExposure.Value, CameraControlFlags.Manual)
            'next we plot the green channel of the select line
            Dim c As Color
            Dim bmp As New Bitmap(VideoSourcePlayer1.GetCurrentVideoFrame())
            yCrop = TrackBarTopCrop.Maximum - TrackBarTopCrop.Value
            nRow = 1080 - yCrop - TrackBarBottomCrop.Value
            Dim gCh(nRow - 1, 1), centroid(1, 1), gCh3_area, gCh3_centroid As Double
            gCh3_centroid = 0
            gCh3_area = 0
            For iG As Integer = 0 To nRow - 1 'This loop stores the Green channel values in the middle column
                gCh(iG, 1) = 0
                For iMovAvg As Integer = 0 To binSize - 1 'Moving average to smooth out the noise
                    c = bmp.GetPixel(TrackBarX.Value - 1, iG + yCrop + iMovAvg)
                    gCh(iG, 1) += c.G
                Next
                gCh(iG, 0) = iG
                If gCh(iG, 1) < 40 * binSize Then
                    gCh(iG, 1) = 0
                End If
                'If CheckBoxCubed.Checked Then
                '    gCh(iG, 1) *= gCh(iG, 1) * gCh(iG, 1) * gCh(iG, 1)
                'End If
                gCh3_centroid += gCh(iG, 1) * iG 'first moment of area
                gCh3_area += gCh(iG, 1)
            Next
            centroid(0, 1) = 0
            centroid(0, 0) = gCh3_centroid / gCh3_area
            centroid(1, 1) = MaxArray1(gCh, nRow)
            centroid(1, 0) = gCh3_centroid / gCh3_area
            Value.Text = gCh3_centroid / gCh3_area
            Application.DoEvents()
            Chart1.RemoveAllDataSeries()
            ' add New data series to the chart
            Chart1.AddDataSeries("Test", Color.Green, Chart1.SeriesType.ConnectedDots, 3)
            ' set X range to display
            Chart1.RangeX = New AForge.Range(0, nRow - 1)
            ' update the chart
            Chart1.UpdateDataSeries("Test", gCh)
            Chart1.AddDataSeries("Centroid", Color.Red, Chart1.SeriesType.ConnectedDots, 3)
            Chart1.UpdateDataSeries("Centroid", centroid)
        Catch ex As Exception
        End Try
    End Sub

    Public Sub TrackBarX_ValueChanged(sender As Object, e As EventArgs) Handles TrackBarX.ValueChanged
        If btnCalibPress Then
            ButtonPlot_Click(sender, e)
        Else
            NumericUpDown_ValueChanged(sender, e)
        End If
    End Sub

    Private Sub TextBoxX_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBoxX.KeyDown
        If e.KeyCode = Keys.Enter Then
            stage.MoveRelative(stage.Xaxe, TextBoxX.Text)
            NumericUpDown_ValueChanged(sender, e)
        End If
    End Sub

    Private Sub TextBoxY_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBoxY.KeyDown
        If e.KeyCode = Keys.Enter Then
            stage.MoveRelative(stage.Yaxe, TextBoxY.Text)
            NumericUpDown_ValueChanged(sender, e)
        End If
    End Sub


    Private Sub TextBoxZ_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBoxZ.KeyDown
        If e.KeyCode = Keys.Enter Then
            stage.MoveRelative(stage.Zaxe, TextBoxZ.Text)
            NumericUpDown_ValueChanged(sender, e)
        End If

    End Sub

    'Function DiracDeltaFit(a As Double, b As Double, x As Double) As Double
    '    Dim pow As Double = (x - b) / a
    '    DiracDeltaFit = -Math.Log(a) - pow * pow
    'End Function

    Public Sub ButtonCalibrate_Click(sender As Object, e As EventArgs) Handles ButtonCalibrate.Click
        btnCalibPress = True
        ButtonSaveCalib.Enabled = True
        ButtonPlot.Enabled = True
        Dim c As Color, gCh3_area, g3, gCh3_centroid As Double
        yCrop = TrackBarTopCrop.Maximum - TrackBarTopCrop.Value
        nRow = 1080 - yCrop - TrackBarBottomCrop.Value
        ReDim laserPosMat(NumericUpDown_n_image.Value - 1, nCol - 1)
        If NumericUpDown_n_image.Value = 1 Then
            Dim bmp As New Bitmap(VideoSourcePlayer1.GetCurrentVideoFrame())
            bmp.Save("c:\temp\" & TextBox4.Text & ".png")
        Else
            stage.MoveRelative(stage.Zaxe, (NumericUpDown_Z_range.Value * -0.0005)) 'go to the bottom most layer'
            For indSeris As Integer = 1 To NumericUpDown_n_image.Value
                Dim bmp_full As New Bitmap(VideoSourcePlayer1.GetCurrentVideoFrame())
                Dim CropRect As New Rectangle(xCrop, yCrop, nCol, nRow)
                Dim bmp = New Bitmap(CropRect.Width, CropRect.Height)
                Using grp = Graphics.FromImage(bmp)
                    grp.DrawImage(bmp_full, New Rectangle(0, 0, CropRect.Width, CropRect.Height), CropRect, GraphicsUnit.Pixel)
                    bmp_full.Dispose()
                    bmp.Save("c:\temp\" & TextBox4.Text & "_" & indSeris.ToString("D2") & ".png")
                End Using
                For iC As Integer = 0 To nCol - 1
                    gCh3_area = 0
                    gCh3_centroid = 0
                    For iR As Integer = 0 To nRow - binSize 'This loop finds the centroidal green pixel in each column
                        g3 = 0
                        For iMovAvg As Integer = 0 To binSize - 1 'Moving average to smooth out the noise
                            c = bmp.GetPixel(iC, iR + iMovAvg)
                            g3 += c.G
                        Next
                        If g3 < 40 * binSize Then
                            g3 = 0
                        End If
                        'g3 *= g3 * g3
                        gCh3_centroid += g3 * iR 'first moment of area
                        gCh3_area += g3
                    Next
                    laserPosMat(indSeris - 1, iC) = gCh3_centroid / gCh3_area
                Next
                If indSeris <> NumericUpDown_n_image.Value Then 'Move the bed up for next scan, except for the final layer
                    stage.MoveRelative(stage.Zaxe, NumericUpDown_Z_range.Value * 0.001 / (NumericUpDown_n_image.Value - 1))
                Else
                    stage.MoveRelative(stage.Zaxe, NumericUpDown_Z_range.Value * -0.0005) 'go to the middle layer'
                End If
            Next
        End If
    End Sub

    Private Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Dim videoDevices As New FilterInfoCollection(FilterCategory.VideoInputDevice)
        Dim videoSource As New VideoCaptureDevice(videoDevices(0).MonikerString)
        VideoSourcePlayer1.VideoSource = videoSource
        videoSource.Stop()
        VideoSourcePlayer1.Stop()
        Exit Sub
    End Sub

    Private Sub ButtonSaveCalib_Click(sender As Object, e As EventArgs) Handles ButtonSaveCalib.Click
        'Try
        '    'Dim FileName As String = "c:\temp\myarray.txt"
        '    'IO.File.WriteAllLines(FileName, laserPosMat.ToString)

        '    Using sw As StreamWriter = New StreamWriter("c:\temp\dataBlue" & TextBox4.Text & ".txt")
        '        For indCol As Integer = 0 To nCol - 1
        '            Dim s As String = ""
        '            For indSeris As Integer = 0 To nSeris - 1
        '                s += laserPosMat(indSeris, indCol).ToString & ","
        '            Next
        '            sw.WriteLine(s)
        '        Next
        '    End Using
        'Catch ex As Exception
        'End Try

        Dim fn As Integer = FreeFile()
        FileOpen(fn, "c:\temp\Calibration_" & TextBox4.Text & ".txt", OpenMode.Output)
        For iY = 0 To laserPosMat.GetUpperBound(1)
            Dim s As String = ""
            For iZ As Integer = 0 To laserPosMat.GetUpperBound(0)
                s += laserPosMat(iZ, iY).ToString & ","
            Next
            PrintLine(fn, s)
        Next
        FileClose(fn)
    End Sub

    Private Sub ButtonPlot_Click(sender As Object, e As EventArgs) Handles ButtonPlot.Click
        Dim calibPlot(laserPosMat.GetUpperBound(0), 1) As Double
        For iSeris As Integer = 0 To laserPosMat.GetUpperBound(0)
            calibPlot(iSeris, 0) = Convert.ToDouble(iSeris) * NumericUpDown_Z_range.Value / NumericUpDown_n_image.Value
            calibPlot(iSeris, 1) = laserPosMat(iSeris, TrackBarX.Value - xCrop)
        Next
        Chart1.RemoveAllDataSeries()
        ' add New data series to the chart
        Chart1.AddDataSeries("laserAtCol", Color.Blue, Chart1.SeriesType.ConnectedDots, 3)
        ' set X range to display
        Dim n_im As Integer = NumericUpDown_n_image.Value
        Chart1.RangeX = New AForge.Range(0, NumericUpDown_Z_range.Value - 1)
        Chart1.UpdateDataSeries("laserAtCol", calibPlot)
    End Sub

    Private Sub ButtonScan_Click(sender As Object, e As EventArgs) Handles ButtonScan.Click
        ReDim sampleZMat(NumericUpDownNLines.Value - 1, nCol - 1)
        Dim c As Color, gCh3_area, g3, gCh3_centroid As Double
        If NumericUpDownNLines.Value = 1 Then
            stage.MoveAbsolute(stage.Xaxe, 12.5, True)
        Else
            stage.MoveAbsolute(stage.Xaxe, 12.5 - NumericUpDown_X_range.Value * 0.5, True) 'bring the first line to laser for scanning
        End If
        Dim xCalib(NumericUpDown_n_image.Value - 1), yCalib(NumericUpDown_n_image.Value - 1) As Double
        xCalib(0) = NumericUpDown_Z_range.Value * -0.0005
        For iZ As Integer = 1 To NumericUpDown_n_image.Value - 1
            xCalib(iZ) = xCalib(iZ - 1) + NumericUpDown_Z_range.Value * 0.001 / (NumericUpDown_n_image.Value - 1)
        Next
        For iLine As Integer = 1 To NumericUpDownNLines.Value
            Dim bmp_full As New Bitmap(VideoSourcePlayer1.GetCurrentVideoFrame())
            Dim CropRect As New Rectangle(xCrop, yCrop, nCol, nRow)
            Dim bmp = New Bitmap(CropRect.Width, CropRect.Height)
            Using grp = Graphics.FromImage(bmp)
                grp.DrawImage(bmp_full, New Rectangle(0, 0, CropRect.Width, CropRect.Height), CropRect, GraphicsUnit.Pixel)
                bmp_full.Dispose()
                'bmp.Save("c:\temp\" & TextBox4.Text & iLine.ToString("D3") & "_" & indSeris.ToString("D2") & ".png")
            End Using
            For iC As Integer = 0 To nCol - 1
                For iR As Integer = 0 To NumericUpDown_n_image.Value - 1
                    'yCalib(iR) = laserPosMat(iR, iC)
                    If iC < binSize \ 2 Then
                        yCalib(iR) = laserPosMat(iR, iC)
                    ElseIf iC > nCol - 1 - binSize \ 2 Then
                        yCalib(iR) = laserPosMat(iR, iC)
                    Else
                        yCalib(iR) = 0
                        For iWin As Integer = -binSize \ 2 To binSize \ 2
                            yCalib(iR) += laserPosMat(iR, iC + iWin)
                        Next
                        yCalib(iR) /= (binSize + 1)
                    End If
                Next
                'Dim naturalSpline As CubicSpline = CubicSpline.InterpolateNatural(xCalib, yCalib)
                Dim akimaSpline As CubicSpline = CubicSpline.InterpolateAkimaSorted(yCalib, xCalib)
                gCh3_area = 0

                gCh3_centroid = 0
                For iR As Integer = 0 To nRow - binSize 'This loop finds the centroidal green pixel in each column
                    g3 = 0
                    For iMovAvg As Integer = 0 To binSize - 1 'Moving average to smooth out the noise
                        c = bmp.GetPixel(iC, iR + iMovAvg)
                        g3 += c.G
                    Next
                    If g3 < 40 * binSize Then
                        g3 = 0
                    End If
                    'g3 *= g3 * g3
                    gCh3_centroid += g3 * iR 'first moment of area
                    gCh3_area += g3
                Next
                gCh3_centroid /= gCh3_area
                'sampleZMat(iLine - 1, iC) = naturalSpline.Interpolate(gCh3_centroid)
                sampleZMat(iLine - 1, iC) = akimaSpline.Interpolate(gCh3_centroid)
                'Barycentric()
                'laserPosMat(indSeris - 1, iC)
            Next
            If iLine <> NumericUpDownNLines.Value Then 'Move the bed along for the next line, except for the final line
                stage.MoveRelative(stage.Xaxe, NumericUpDown_X_range.Value / (NumericUpDownNLines.Value - 1))
            End If
        Next
        stage.MoveAbsolute(stage.Xaxe, 12.5, True)
    End Sub

    Private Sub ButtonSaveScan_Click(sender As Object, e As EventArgs) Handles ButtonSaveScan.Click
        Dim fn As Integer = FreeFile()
        FileOpen(fn, "c:\temp\SampleZmap_" & TextBox4.Text & ".txt", OpenMode.Output)
        For iX = 0 To sampleZMat.GetUpperBound(0)
            Dim s As String = ""
            For iY As Integer = 0 To sampleZMat.GetUpperBound(1)
                s += sampleZMat(iX, iY).ToString & ","
            Next
            PrintLine(fn, s)
        Next
        FileClose(fn)
        'Chart1.AddDataSeries()
    End Sub
End Class